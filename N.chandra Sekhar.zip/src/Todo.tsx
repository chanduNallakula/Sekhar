// src/components/Todo.tsx

import React from "react";
import "./TodoList.css"; // Import CSS file

interface TodoProps {
  todo: string;
  completed: boolean;
  onDelete: () => void;
  onToggle: () => void;
  onEdit: (newText: string) => void;
}

const Todo: React.FC<TodoProps> = ({
  todo,
  completed,
  onDelete,
  onToggle,
  onEdit,
}) => {
  const handleEdit = () => {
    const newTodo = prompt("Edit Todo:", todo);
    if (newTodo !== null && newTodo.trim() !== "") {
      onEdit(newTodo);
    }
  };

  return (
    <div className={`todo-item ${completed ? "completed" : ""}`}>
      <input
        type="checkbox"
        checked={completed}
        onChange={onToggle}
        className="todo-checkbox"
      />
      <span className="todo-text">{todo}</span>
      <div>
        <button onClick={handleEdit} className="edit-button">
          Edit
        </button>
        <button onClick={onDelete} className="delete-button">
          Delete
        </button>
      </div>
    </div>
  );
};

export default Todo;
