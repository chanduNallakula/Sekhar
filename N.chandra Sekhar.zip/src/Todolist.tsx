// src/components/TodoList.tsx

import React, { useState } from "react";
import Todo from "./Todo";
import "./TodoList.css"; // Import CSS file

const TodoList: React.FC = () => {
  const [todos, setTodos] = useState<{ text: string; completed: boolean }[]>(
    []
  );
  const [inputValue, setInputValue] = useState<string>("");

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setInputValue(e.target.value);
  };

  const handleAddTodo = () => {
    if (inputValue.trim() !== "") {
      setTodos([...todos, { text: inputValue.trim(), completed: false }]);
      setInputValue("");
    }
  };

  const handleDeleteTodo = (index: number) => {
    const newTodos = [...todos];
    newTodos.splice(index, 1);
    setTodos(newTodos);
  };

  const handleToggleTodo = (index: number) => {
    const newTodos = [...todos];
    newTodos[index].completed = !newTodos[index].completed;
    setTodos(newTodos);
  };

  return (
    <div className="todo-list-container">
      <h2>Todo List</h2>
      <div className="todo-input-container">
        <input
          type="text"
          value={inputValue}
          onChange={handleInputChange}
          className="todo-input"
          placeholder="Enter a new todo"
        />
        <button onClick={handleAddTodo} className="todo-button">
          Add
        </button>
      </div>
      <ul>
        {todos.map((todo, index) => (
          <li key={index}>
            <Todo
              todo={todo.text}
              completed={todo.completed}
              onDelete={() => handleDeleteTodo(index)}
              onToggle={() => handleToggleTodo(index)}
            />
          </li>
        ))}
      </ul>
    </div>
  );
};

export default TodoList;
