// src/App.tsx

import React from "react";
import Todolist from "./Todolist";

const App: React.FC = () => {
  return (
    <div className="App">
      <h1>Todo List App</h1>
      <Todolist />
    </div>
  );
};

export default App;
